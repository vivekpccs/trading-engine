"""
Main scheduler - runs the trading advisory engine every 5 minutes
"""
import time
import logging
from datetime import datetime
from app.data_source import fetch_nifty_data, get_latest_price, validate_data_quality
from app.indicators import calculate_all_indicators
from app.strategy import generate_signal, should_log_to_history
from app.state_store import load_state, get_cooldown_remaining_seconds
from app.log_store import (
    append_to_csv,
    write_latest_status,
    get_last_logged_price,
    initialize_csv_if_needed
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


def run_strategy_cycle():
    """
    Execute one complete strategy cycle:
    1. Fetch data
    2. Calculate indicators
    3. Generate signal
    4. Log results
    """
    try:
        logger.info("=" * 60)
        logger.info("Starting new strategy cycle")
        logger.info("=" * 60)
        
        # Step 1: Fetch market data
        logger.info("Step 1: Fetching NIFTY data...")
        df = fetch_nifty_data(symbol="^NSEI", interval="5m", days=2, max_retries=1)
        
        if df is None or df.empty:
            logger.error("Failed to fetch data. Skipping this cycle.")
            return
        
        # Validate data quality
        if not validate_data_quality(df):
            logger.error("Data quality check failed. Skipping this cycle.")
            return
        
        # Get current price
        price = get_latest_price(df)
        if price is None:
            logger.error("Failed to extract price. Skipping this cycle.")
            return
        
        logger.info(f"Current NIFTY price: ₹{price:.2f}")
        
        # Step 2: Calculate indicators
        logger.info("Step 2: Calculating indicators...")
        indicators = calculate_all_indicators(df)
        
        if indicators is None:
            logger.error("Failed to calculate indicators. Skipping this cycle.")
            return
        
        # Step 3: Generate signal
        logger.info("Step 3: Generating signal...")
        signal_result = generate_signal(indicators, price)
        
        signal = signal_result['signal']
        state = signal_result['state']
        reason = signal_result['reason']
        action_taken = signal_result['action_taken']
        
        logger.info(f"Signal: {signal}")
        logger.info(f"State: {state}")
        logger.info(f"Reason: {reason}")
        logger.info(f"Action taken: {action_taken}")
        
        # Get cooldown info
        current_state = load_state()
        cooldown_remaining = get_cooldown_remaining_seconds(current_state)
        
        # Prepare data package
        signal_data = {
            'timestamp_utc': datetime.utcnow().isoformat(),
            'symbol': '^NSEI',
            'price': price,
            'ema9': indicators['ema9'],
            'ema21': indicators['ema21'],
            'rsi14': indicators['rsi14'],
            'signal': signal,
            'state': state,
            'reason': reason,
            'cooldown_remaining_sec': cooldown_remaining,
            'action_taken': action_taken
        }
        
        # Step 4: Log results
        logger.info("Step 4: Logging results...")
        
        # Always write latest status (for dashboard/API)
        write_latest_status(signal_data)
        
        # Conditionally log to CSV (avoid spam)
        last_price = get_last_logged_price()
        if should_log_to_history(signal_data, last_price):
            append_to_csv(signal_data)
            logger.info("Logged to CSV history")
        else:
            logger.info("Skipped CSV logging (no significant change)")
        
        logger.info("Cycle completed successfully")
        logger.info("=" * 60)
        
    except Exception as e:
        logger.error(f"Error in strategy cycle: {str(e)}", exc_info=True)
        logger.error("Continuing to next cycle...")


def main():
    """
    Main loop - run strategy every 5 minutes forever
    """
    logger.info("=" * 60)
    logger.info("NIFTY Trading Advisory Engine Starting")
    logger.info("=" * 60)
    logger.info("Strategy: EMA Crossover + RSI Filter")
    logger.info("Interval: 5 minutes")
    logger.info("Symbol: ^NSEI (NIFTY 50)")
    logger.info("Mode: ADVISORY ONLY (No execution)")
    logger.info("=" * 60)
    
    # Initialize CSV file if needed
    initialize_csv_if_needed()
    
    # Load and display current state
    initial_state = load_state()
    logger.info(f"Initial state: {initial_state.get('current_state', 'NONE')}")
    
    cycle_count = 0
    
    while True:
        try:
            cycle_count += 1
            logger.info(f"\n\n>>> Cycle #{cycle_count} at {datetime.utcnow().isoformat()} UTC")
            
            # Run one strategy cycle
            run_strategy_cycle()
            
            # Wait 5 minutes before next cycle
            wait_seconds = 5 * 60
            logger.info(f"Waiting {wait_seconds} seconds until next cycle...")
            time.sleep(wait_seconds)
            
        except KeyboardInterrupt:
            logger.info("\n\nReceived shutdown signal (Ctrl+C)")
            logger.info("Gracefully stopping engine...")
            break
            
        except Exception as e:
            logger.error(f"Unexpected error in main loop: {str(e)}", exc_info=True)
            logger.error("Waiting 5 minutes before retry...")
            time.sleep(5 * 60)
    
    logger.info("=" * 60)
    logger.info("Engine stopped")
    logger.info("=" * 60)


if __name__ == "__main__":
    main()
