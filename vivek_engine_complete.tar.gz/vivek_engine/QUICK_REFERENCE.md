# 🚀 Quick Reference Guide

## SSH Connection

```bash
# Connect to VPS
ssh root@your-vps-ip

# With SSH tunnel for dashboard/API access
ssh -L 8501:localhost:8501 -L 8000:localhost:8000 root@your-vps-ip
```

---

## Starting Services Manually

```bash
cd ~/vivek_engine
source venv/bin/activate

# Terminal 1: Main Engine
python main_scheduler.py

# Terminal 2: API
uvicorn app.api:app --host 127.0.0.1 --port 8000

# Terminal 3: Dashboard
streamlit run app/dashboard.py --server.address 127.0.0.1 --server.port 8501
```

---

## Using Screen (Multiple Sessions)

```bash
# Start sessions
screen -S scheduler     # Run: python main_scheduler.py
screen -S api          # Run: uvicorn app.api:app --host 127.0.0.1 --port 8000
screen -S dashboard    # Run: streamlit run app/dashboard.py --server.address 127.0.0.1 --server.port 8501

# Detach from session: Ctrl+A, then D

# List sessions
screen -ls

# Reattach to session
screen -r scheduler
screen -r api
screen -r dashboard

# Kill session
screen -X -S scheduler quit
```

---

## Systemd Services (Auto-start)

```bash
# Start services
sudo systemctl start vivek-engine.service
sudo systemctl start vivek-api.service
sudo systemctl start vivek-dashboard.service

# Stop services
sudo systemctl stop vivek-engine.service
sudo systemctl stop vivek-api.service
sudo systemctl stop vivek-dashboard.service

# Restart services
sudo systemctl restart vivek-engine.service
sudo systemctl restart vivek-api.service
sudo systemctl restart vivek-dashboard.service

# Check status
sudo systemctl status vivek-engine.service
sudo systemctl status vivek-api.service
sudo systemctl status vivek-dashboard.service

# Enable auto-start on boot
sudo systemctl enable vivek-engine.service
sudo systemctl enable vivek-api.service
sudo systemctl enable vivek-dashboard.service

# Disable auto-start
sudo systemctl disable vivek-engine.service
```

---

## Viewing Logs

```bash
# Main application log
tail -f ~/vivek_engine/logs/app.log

# Last 50 lines
tail -n 50 ~/vivek_engine/logs/app.log

# Systemd service logs
sudo journalctl -u vivek-engine.service -f
sudo journalctl -u vivek-api.service -f
sudo journalctl -u vivek-dashboard.service -f

# Last 100 lines from service
sudo journalctl -u vivek-engine.service -n 100
```

---

## Checking Data Files

```bash
cd ~/vivek_engine

# Current state
cat data/state.json

# Latest status
cat data/latest_status.json

# Signal history (last 20)
tail -n 20 data/signals.csv

# Count total signals
wc -l data/signals.csv
```

---

## Testing API

```bash
# Test status endpoint
curl http://127.0.0.1:8000/status | python3 -m json.tool

# Test history endpoint
curl http://127.0.0.1:8000/history?limit=10 | python3 -m json.tool

# Health check
curl http://127.0.0.1:8000/health
```

---

## Access URLs (from your laptop after SSH tunnel)

```
Dashboard:  http://localhost:8501
API Status: http://localhost:8000/status
API Docs:   http://localhost:8000/docs
History:    http://localhost:8000/history?limit=50
```

---

## Backup

```bash
# Create backup
cd ~
tar -czf vivek_backup_$(date +%Y%m%d_%H%M%S).tar.gz vivek_engine/data/ vivek_engine/logs/

# List backups
ls -lh vivek_backup_*.tar.gz

# Download backup to laptop (run on laptop)
scp root@your-vps-ip:~/vivek_backup_*.tar.gz ~/Downloads/
```

---

## Restore from Backup

```bash
# Extract backup
cd ~
tar -xzf vivek_backup_20240115_143000.tar.gz

# Restart services
sudo systemctl restart vivek-engine.service
sudo systemctl restart vivek-api.service
sudo systemctl restart vivek-dashboard.service
```

---

## Updating Code

```bash
# Stop services
sudo systemctl stop vivek-engine.service
sudo systemctl stop vivek-api.service
sudo systemctl stop vivek-dashboard.service

# Backup current state
cp data/state.json data/state.json.bak
cp data/signals.csv data/signals.csv.bak

# Update code (if using git)
cd ~/vivek_engine
git pull

# Or upload new files via SCP

# Reinstall dependencies (if requirements changed)
source venv/bin/activate
pip install -r requirements.txt

# Start services
sudo systemctl start vivek-engine.service
sudo systemctl start vivek-api.service
sudo systemctl start vivek-dashboard.service
```

---

## Troubleshooting Commands

```bash
# Check if Python is installed
python3.10 --version

# Check if venv is activated
which python    # Should show: /root/vivek_engine/venv/bin/python

# Reinstall dependencies
cd ~/vivek_engine
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Check disk space
df -h

# Check memory usage
free -h

# Check processes
ps aux | grep python
ps aux | grep streamlit
ps aux | grep uvicorn

# Kill stuck process
pkill -f main_scheduler
pkill -f streamlit
pkill -f uvicorn

# Reset state (CAREFUL: loses current position)
echo '{
  "current_state": "NONE",
  "last_signal": null,
  "last_action_time_utc": null,
  "cooldown_end_time_utc": null
}' > ~/vivek_engine/data/state.json

# Check network connectivity
ping -c 3 google.com
curl -I https://finance.yahoo.com
```

---

## File Permissions

```bash
# Fix permissions if needed
cd ~/vivek_engine
chmod 644 data/*.json
chmod 644 data/*.csv
chmod 755 data logs
chmod +x init_setup.sh
```

---

## System Maintenance

```bash
# Update VPS packages
sudo apt update && sudo apt upgrade -y

# Clean old logs (keep last 1000 lines)
cd ~/vivek_engine
tail -n 1000 logs/app.log > logs/app.log.tmp
mv logs/app.log.tmp logs/app.log

# Archive old signal data
cp data/signals.csv data/signals_archive_$(date +%Y%m%d).csv
```

---

## Environment Variables

```bash
# Check current path
echo $PATH

# Show Python location
which python3.10

# Show venv Python
source ~/vivek_engine/venv/bin/activate
which python
```

---

## Installation from Scratch

```bash
# Full setup in one go
cd ~
mkdir -p vivek_engine
cd vivek_engine

# (Upload all files here)

python3.10 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

bash init_setup.sh

python main_scheduler.py  # Test run
```

---

## Emergency Stop

```bash
# Stop everything immediately
sudo systemctl stop vivek-engine.service
sudo systemctl stop vivek-api.service
sudo systemctl stop vivek-dashboard.service

# Or kill all processes
pkill -f main_scheduler
pkill -f "uvicorn app.api"
pkill -f "streamlit run"
```

---

## Useful Aliases (Optional - add to ~/.bashrc)

```bash
# Add these to make life easier
echo "alias venv='source ~/vivek_engine/venv/bin/activate'" >> ~/.bashrc
echo "alias engine='cd ~/vivek_engine'" >> ~/.bashrc
echo "alias logs='tail -f ~/vivek_engine/logs/app.log'" >> ~/.bashrc
echo "alias status='sudo systemctl status vivek-engine.service'" >> ~/.bashrc

# Reload bashrc
source ~/.bashrc

# Now you can use:
engine     # Go to project directory
venv       # Activate virtual environment
logs       # View logs
status     # Check engine status
```

---

## Market Hours Reference

**Indian Stock Market (NSE/BSE)**
- Trading Hours: 9:15 AM - 3:30 PM IST (Mon-Fri)
- Pre-market: 9:00 AM - 9:15 AM IST
- Closed: Weekends and public holidays

**Note**: NIFTY data via Yahoo Finance may have slight delays during market hours.

---

## Important File Locations

```
~/vivek_engine/
├── data/state.json              ← Current position state
├── data/signals.csv             ← Signal history
├── data/latest_status.json      ← Current snapshot
├── logs/app.log                 ← Application logs
├── app/strategy.py              ← Strategy parameters
├── requirements.txt             ← Dependencies
└── README.md                    ← Full documentation
```

---

## Performance Monitoring

```bash
# CPU usage
top

# Memory usage
free -h

# Disk usage
df -h

# Network usage
iftop  # (install: sudo apt install iftop)

# Process stats for engine
ps aux | grep main_scheduler
```

---

## Quick Health Check

```bash
# Run this to check if everything is working
cd ~/vivek_engine

echo "=== Checking Services ==="
sudo systemctl is-active vivek-engine.service
sudo systemctl is-active vivek-api.service
sudo systemctl is-active vivek-dashboard.service

echo -e "\n=== Checking Data Files ==="
ls -lh data/

echo -e "\n=== Latest Status ==="
cat data/latest_status.json

echo -e "\n=== Recent Signals ==="
tail -n 5 data/signals.csv

echo -e "\n=== API Test ==="
curl -s http://127.0.0.1:8000/health
```

---

**Save this file for quick reference!**

For detailed explanations, see:
- README.md (Complete documentation)
- DEPLOYMENT_GUIDE.md (Step-by-step setup)
