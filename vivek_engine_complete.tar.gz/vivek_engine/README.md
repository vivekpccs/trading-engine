# NIFTY Trading Advisory Engine

A disciplined, production-ready options trading advisory system for the Indian market (NIFTY 50). This engine generates clear, repeatable trading signals based on EMA crossovers and RSI filters, with built-in state management and cooldown discipline.

## ⚠️ Important Notice

**This is an ADVISORY ONLY system** - it does NOT place trades or connect to brokers. It provides signals that you can use to make informed trading decisions.

---

## 🎯 Features

- **State Machine Logic**: Tracks position bias (NONE/LONG/SHORT) to avoid signal spam
- **Cooldown Discipline**: 15-minute cooldown after exits to prevent whipsaws
- **Persistent State**: Survives server restarts without losing position state
- **Clean Logging**: CSV history + JSON snapshots for review and analysis
- **REST API**: FastAPI endpoints for programmatic access
- **Live Dashboard**: Streamlit web interface with auto-refresh
- **Secure by Default**: Binds to localhost only (access via SSH tunnel)

---

## 📊 Strategy

### Signals

- **STRONG_BUY**: EMA9 crosses above EMA21 AND RSI > 55 (only when state = NONE, not in cooldown)
- **STRONG_SELL**: EMA9 crosses below EMA21 AND RSI < 45 (only when state = NONE, not in cooldown)
- **EXIT_LONG**: EMA9 crosses below EMA21 (when state = LONG)
- **EXIT_SHORT**: EMA9 crosses above EMA21 (when state = SHORT)
- **HOLD**: No action conditions met
- **COOLDOWN**: Blocking new entries after recent exit

### State Management

- **NONE**: No position bias
- **LONG**: In long position after buy signal
- **SHORT**: In short position after sell signal

### Discipline Rules

1. Cannot enter new position while in LONG or SHORT state
2. Must exit before entering opposite direction
3. 15-minute cooldown after any exit (EXIT_LONG or EXIT_SHORT)
4. Duplicate HOLD signals not logged unless price moves >0.5%

---

## 📁 Project Structure

```
vivek_engine/
├── app/
│   ├── __init__.py           # Package marker
│   ├── data_source.py        # yfinance data fetcher
│   ├── indicators.py         # EMA, RSI calculations
│   ├── strategy.py           # Signal generation + state machine
│   ├── state_store.py        # State persistence (JSON)
│   ├── log_store.py          # CSV + JSON logging
│   ├── api.py                # FastAPI REST endpoints
│   └── dashboard.py          # Streamlit dashboard
├── data/
│   ├── state.json            # Current state (NONE/LONG/SHORT)
│   ├── signals.csv           # Signal history log
│   └── latest_status.json    # Current snapshot
├── logs/
│   └── app.log               # Application logs
├── main_scheduler.py         # Main engine (runs every 5 min)
├── requirements.txt          # Python dependencies
└── README.md                 # This file
```

---

## 🚀 VPS Setup Guide (Ubuntu)

### Step 1: Install Python (if needed)

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python 3.10+
sudo apt install python3.10 python3.10-venv python3-pip -y

# Verify installation
python3.10 --version
```

### Step 2: Create Project Directory

```bash
# Create project folder
mkdir -p vivek_engine
cd vivek_engine

# Upload all project files here
# (Use SCP, SFTP, or Git to transfer files)
```

### Step 3: Set Up Virtual Environment

```bash
# Create virtual environment
python3.10 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
pip install --upgrade pip
```

### Step 4: Install Dependencies

```bash
# Install all required packages
pip install -r requirements.txt
```

### Step 5: Initialize Data Files

```bash
# Create directories
mkdir -p data logs

# Initialize state.json
echo '{
  "current_state": "NONE",
  "last_signal": null,
  "last_action_time_utc": null,
  "cooldown_end_time_utc": null
}' > data/state.json

# Create empty CSV (headers will be added automatically)
touch data/signals.csv

# Create empty status file
echo '{}' > data/latest_status.json

# Set proper permissions
chmod 644 data/*.json data/*.csv
```

---

## ▶️ Running the System

You need **three separate terminal sessions** (or use `tmux`/`screen`):

### Terminal 1: Main Scheduler (Strategy Engine)

```bash
cd vivek_engine
source venv/bin/activate
python main_scheduler.py
```

**What it does**: Runs strategy every 5 minutes, generates signals, updates state and logs.

**Expected output**:
```
2024-01-15 10:00:00 - INFO - NIFTY Trading Advisory Engine Starting
2024-01-15 10:00:00 - INFO - Strategy: EMA Crossover + RSI Filter
2024-01-15 10:00:05 - INFO - Fetching NIFTY data...
2024-01-15 10:00:10 - INFO - Current NIFTY price: ₹21,453.25
2024-01-15 10:00:12 - INFO - Indicators calculated: EMA9=21450.30, EMA21=21445.50, RSI=58.23
2024-01-15 10:00:12 - INFO - Signal: HOLD
```

### Terminal 2: API Server

```bash
cd vivek_engine
source venv/bin/activate
uvicorn app.api:app --host 127.0.0.1 --port 8000 --reload
```

**What it does**: Runs REST API on `http://127.0.0.1:8000`

**Test locally on VPS**:
```bash
curl http://127.0.0.1:8000/status
curl http://127.0.0.1:8000/history?limit=10
```

### Terminal 3: Dashboard

```bash
cd vivek_engine
source venv/bin/activate
streamlit run app/dashboard.py --server.address 127.0.0.1 --server.port 8501
```

**What it does**: Runs Streamlit dashboard on `http://127.0.0.1:8501`

---

## 🔐 Accessing from Your Laptop (SSH Tunnel)

Since the API and Dashboard bind to `127.0.0.1` (localhost only), you need SSH port forwarding to access them securely from your laptop.

### From Your Laptop Terminal:

```bash
# Replace 'your-vps-ip' with your actual VPS IP address
# Replace 'your-username' with your VPS username (e.g., ubuntu, root)

ssh -L 8501:localhost:8501 -L 8000:localhost:8000 your-username@your-vps-ip
```

**Example**:
```bash
ssh -L 8501:localhost:8501 -L 8000:localhost:8000 ubuntu@203.0.113.45
```

### Then Open in Your Browser:

- **Dashboard**: http://localhost:8501
- **API Status**: http://localhost:8000/status
- **API History**: http://localhost:8000/history

The SSH tunnel stays open as long as the terminal is connected. If you close the terminal, you'll need to reconnect.

---

## 🛠️ Production Deployment (Optional - Systemd Services)

For production use, you can run components as systemd services so they auto-start on boot.

### 1. Create Service for Main Scheduler

```bash
sudo nano /etc/systemd/system/vivek-engine.service
```

**Content**:
```ini
[Unit]
Description=NIFTY Trading Advisory Engine
After=network.target

[Service]
Type=simple
User=your-username
WorkingDirectory=/home/your-username/vivek_engine
Environment="PATH=/home/your-username/vivek_engine/venv/bin"
ExecStart=/home/your-username/vivek_engine/venv/bin/python main_scheduler.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### 2. Create Service for API

```bash
sudo nano /etc/systemd/system/vivek-api.service
```

**Content**:
```ini
[Unit]
Description=NIFTY Trading Advisory API
After=network.target

[Service]
Type=simple
User=your-username
WorkingDirectory=/home/your-username/vivek_engine
Environment="PATH=/home/your-username/vivek_engine/venv/bin"
ExecStart=/home/your-username/vivek_engine/venv/bin/uvicorn app.api:app --host 127.0.0.1 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### 3. Create Service for Dashboard

```bash
sudo nano /etc/systemd/system/vivek-dashboard.service
```

**Content**:
```ini
[Unit]
Description=NIFTY Trading Advisory Dashboard
After=network.target

[Service]
Type=simple
User=your-username
WorkingDirectory=/home/your-username/vivek_engine
Environment="PATH=/home/your-username/vivek_engine/venv/bin"
ExecStart=/home/your-username/vivek_engine/venv/bin/streamlit run app/dashboard.py --server.address 127.0.0.1 --server.port 8501
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### 4. Enable and Start Services

```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable auto-start on boot
sudo systemctl enable vivek-engine.service
sudo systemctl enable vivek-api.service
sudo systemctl enable vivek-dashboard.service

# Start services
sudo systemctl start vivek-engine.service
sudo systemctl start vivek-api.service
sudo systemctl start vivek-dashboard.service

# Check status
sudo systemctl status vivek-engine.service
sudo systemctl status vivek-api.service
sudo systemctl status vivek-dashboard.service
```

### 5. Useful Commands

```bash
# View logs
sudo journalctl -u vivek-engine.service -f
sudo journalctl -u vivek-api.service -f
sudo journalctl -u vivek-dashboard.service -f

# Restart services
sudo systemctl restart vivek-engine.service
sudo systemctl restart vivek-api.service
sudo systemctl restart vivek-dashboard.service

# Stop services
sudo systemctl stop vivek-engine.service
sudo systemctl stop vivek-api.service
sudo systemctl stop vivek-dashboard.service
```

---

## 📊 API Endpoints

### GET /status

Returns current advisory status.

**Response**:
```json
{
  "timestamp_utc": "2024-01-15T10:30:00.000000",
  "symbol": "^NSEI",
  "price": 21453.25,
  "ema9": 21450.30,
  "ema21": 21445.50,
  "rsi14": 58.23,
  "signal": "HOLD",
  "state": "NONE",
  "reason": "No crossover detected. EMA9=21450.30, EMA21=21445.50, RSI=58.23",
  "cooldown_remaining_sec": 0
}
```

### GET /history?limit=50

Returns last N signal events.

**Parameters**:
- `limit` (optional): Number of records (1-500, default 50)

**Response**:
```json
{
  "count": 10,
  "limit": 50,
  "signals": [
    {
      "timestamp_utc": "2024-01-15T10:30:00",
      "symbol": "^NSEI",
      "price": "21453.25",
      "ema9": "21450.30",
      "ema21": "21445.50",
      "rsi14": "58.23",
      "signal": "STRONG_BUY",
      "state": "LONG",
      "cooldown_remaining_sec": "0"
    }
  ]
}
```

---

## 🐛 Troubleshooting

### Issue: "Module not found" errors

**Solution**:
```bash
# Make sure you're in the venv
source venv/bin/activate

# Reinstall dependencies
pip install -r requirements.txt
```

### Issue: "Permission denied" on data files

**Solution**:
```bash
chmod 644 data/*.json data/*.csv
chmod 755 data logs
```

### Issue: yfinance fails to fetch data

**Possible causes**:
- Market is closed (Indian market hours: 9:15 AM - 3:30 PM IST)
- Internet connection issue
- Yahoo Finance temporary outage

**Check logs**:
```bash
tail -f logs/app.log
```

### Issue: Dashboard shows "No data available"

**Solution**:
1. Check if scheduler is running: `ps aux | grep main_scheduler`
2. Check if data files exist: `ls -la data/`
3. Wait 5 minutes for first cycle to complete
4. Check logs: `tail -f logs/app.log`

### Issue: Cannot access dashboard from laptop

**Solution**:
1. Verify SSH tunnel is active
2. Check services are running on VPS:
   ```bash
   curl http://127.0.0.1:8501
   curl http://127.0.0.1:8000/status
   ```
3. Re-establish SSH tunnel with correct port forwarding

---

## 📈 Understanding the Logs

### Main Log File: `logs/app.log`

```
2024-01-15 10:00:00 - INFO - Starting new strategy cycle
2024-01-15 10:00:01 - INFO - Fetching NIFTY data...
2024-01-15 10:00:05 - INFO - Successfully fetched 200 rows of data
2024-01-15 10:00:05 - INFO - Current NIFTY price: ₹21,453.25
2024-01-15 10:00:06 - INFO - Indicators calculated: EMA9=21450.30, EMA21=21445.50, RSI=58.23
2024-01-15 10:00:06 - INFO - Strategy check: State=NONE, Crossover=bullish, RSI=58.23
2024-01-15 10:00:06 - INFO - STRONG_BUY triggered: Bullish crossover + RSI 58.23 > 55
2024-01-15 10:00:06 - INFO - State saved: LONG
2024-01-15 10:00:06 - INFO - Signal: STRONG_BUY
2024-01-15 10:00:06 - INFO - Logged to CSV history
2024-01-15 10:00:06 - INFO - Cycle completed successfully
```

### CSV Log: `data/signals.csv`

Contains timestamped history of all meaningful signal events.

### State File: `data/state.json`

Current state of the engine (persists across restarts).

---

## 🔄 Maintenance

### Backup Important Files

```bash
# Backup state and history
tar -czf backup_$(date +%Y%m%d).tar.gz data/ logs/

# Optional: Upload to cloud storage
```

### Clear Old Logs (if needed)

```bash
# Keep last 1000 lines of app.log
tail -n 1000 logs/app.log > logs/app.log.tmp
mv logs/app.log.tmp logs/app.log

# Archive old CSV data
cp data/signals.csv data/signals_archive_$(date +%Y%m%d).csv
```

---

## 🚀 Future Enhancements (Phase 2 & 3)

### Phase 2: Auto Execution
- Zerodha/broker API integration
- Order placement logic
- Risk management (position sizing, max loss)
- Stop-loss and trailing stop implementation
- Trade lifecycle management

### Phase 3: SaaS
- Multi-user authentication
- Per-user strategy configurations
- Subscription management
- Performance analytics dashboard
- Mobile app
- Alerts (Telegram, WhatsApp, Email)

---

## 📞 Support

For issues or questions:
1. Check logs: `logs/app.log`
2. Verify data files exist and are readable
3. Ensure VPS has internet connectivity
4. Check if market is open (IST 9:15 AM - 3:30 PM)

---

## ⚖️ Disclaimer

**This software is for educational and informational purposes only.**

- NOT financial advice
- NO guarantees of profitability
- Trading involves substantial risk of loss
- Test thoroughly before using real money
- Consult a licensed financial advisor before trading

**Use at your own risk.**

---

## 📝 License

Copyright © 2024. All rights reserved.

---

**Version**: 1.0.0  
**Last Updated**: January 2024  
**Author**: Vivek
