# 🚀 COMPLETE VPS DEPLOYMENT GUIDE (Non-Technical)

This guide will walk you through deploying the NIFTY Trading Advisory Engine on a VPS, step by step.

---

## 📋 Prerequisites

Before starting, you'll need:

1. **A VPS (Virtual Private Server)**
   - Recommended providers: DigitalOcean, Linode, Vultr, or AWS Lightsail
   - Minimum specs: 1 CPU, 1GB RAM, 25GB storage
   - Operating System: Ubuntu 22.04 or 24.04
   - Cost: ~$5-10/month

2. **SSH Access**
   - For Windows: Download [PuTTY](https://www.putty.org/)
   - For Mac/Linux: Built-in Terminal app

3. **Your VPS Information**
   - IP Address (e.g., 203.0.113.45)
   - Username (usually `root` or `ubuntu`)
   - Password or SSH key

---

## PART 1: Getting a VPS (DigitalOcean Example)

### Step 1: Create Account

1. Go to [DigitalOcean.com](https://www.digitalocean.com/)
2. Sign up for an account
3. Verify email
4. Add payment method

### Step 2: Create Droplet (VPS)

1. Click **"Create"** → **"Droplets"**
2. Choose **Ubuntu 22.04 LTS**
3. Select plan: **Basic** → **Regular** → **$6/month** (1GB RAM)
4. Choose datacenter: Select closest to India (e.g., Bangalore)
5. Authentication: Choose **SSH Key** (recommended) or **Password**
6. Hostname: `trading-engine`
7. Click **"Create Droplet"**

### Step 3: Note Your VPS Details

After creation, you'll see:
- **IP Address**: `203.0.113.45` (example)
- **Username**: `root`
- **Password**: (sent via email if you chose password auth)

**Write these down!**

---

## PART 2: Connecting to Your VPS

### For Windows Users (PuTTY)

1. Download and install [PuTTY](https://www.putty.org/)
2. Open PuTTY
3. In "Host Name" field, enter your VPS IP: `203.0.113.45`
4. Port: `22`
5. Click **"Open"**
6. Security alert: Click **"Yes"**
7. Login as: `root` (press Enter)
8. Password: (paste your password, won't show on screen)
9. You're in! You'll see a command prompt like: `root@trading-engine:~#`

### For Mac/Linux Users (Terminal)

1. Open **Terminal** app
2. Type: `ssh root@203.0.113.45` (use your IP)
3. Type `yes` if asked about fingerprint
4. Enter password when prompted
5. You're in!

---

## PART 3: Installing Dependencies on VPS

Copy and paste these commands one by one into your SSH terminal.

### Step 1: Update System

```bash
sudo apt update && sudo apt upgrade -y
```

Press Enter. This will take 2-5 minutes.

### Step 2: Install Python

```bash
sudo apt install python3.10 python3.10-venv python3-pip -y
```

### Step 3: Verify Installation

```bash
python3.10 --version
```

You should see: `Python 3.10.x`

---

## PART 4: Upload Project Files to VPS

You have several options:

### Option A: Using SCP (Recommended for beginners)

**On your laptop (not VPS):**

1. Download all project files to a folder: `vivek_engine/`
2. Open Terminal/Command Prompt
3. Navigate to parent directory:
   ```bash
   cd /path/to/folder/containing/vivek_engine
   ```
4. Upload to VPS:
   ```bash
   scp -r vivek_engine root@203.0.113.45:~/
   ```
5. Enter password when prompted

### Option B: Using WinSCP (Windows, GUI-based)

1. Download [WinSCP](https://winscp.net/)
2. Install and open
3. Enter:
   - Host name: Your VPS IP
   - User name: root
   - Password: Your password
4. Click **Login**
5. Drag and drop `vivek_engine` folder from left (your computer) to right (VPS)

### Option C: Using Git (if files are in a repository)

**On VPS:**
```bash
cd ~
git clone https://github.com/yourusername/vivek_engine.git
```

---

## PART 5: Setting Up the Project on VPS

Now you're working on the VPS via SSH.

### Step 1: Navigate to Project

```bash
cd ~/vivek_engine
```

### Step 2: Create Virtual Environment

```bash
python3.10 -m venv venv
```

### Step 3: Activate Virtual Environment

```bash
source venv/bin/activate
```

Your prompt will change to show `(venv)` at the beginning.

### Step 4: Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

This takes 2-3 minutes. You'll see lots of "Successfully installed..." messages.

### Step 5: Initialize Data Files

Run the initialization script:

```bash
bash init_setup.sh
```

Or manually:

```bash
mkdir -p data logs

echo '{
  "current_state": "NONE",
  "last_signal": null,
  "last_action_time_utc": null,
  "cooldown_end_time_utc": null
}' > data/state.json

touch data/signals.csv
echo '{}' > data/latest_status.json
```

---

## PART 6: Running the System

You'll need **3 terminal sessions**. Here's how:

### Using Screen (Recommended for VPS)

Screen lets you run multiple sessions that stay alive even if you disconnect.

**Install screen:**
```bash
sudo apt install screen -y
```

#### Session 1: Main Scheduler

```bash
screen -S scheduler
source venv/bin/activate
python main_scheduler.py
```

- Press **Ctrl+A**, then **D** to detach (leave it running)

#### Session 2: API Server

```bash
screen -S api
source venv/bin/activate
uvicorn app.api:app --host 127.0.0.1 --port 8000
```

- Press **Ctrl+A**, then **D** to detach

#### Session 3: Dashboard

```bash
screen -S dashboard
source venv/bin/activate
streamlit run app/dashboard.py --server.address 127.0.0.1 --server.port 8501
```

- Press **Ctrl+A**, then **D** to detach

### Managing Screen Sessions

```bash
# List all sessions
screen -ls

# Reattach to a session
screen -r scheduler
screen -r api
screen -r dashboard

# Kill a session (if needed)
screen -X -S scheduler quit
```

---

## PART 7: Accessing from Your Laptop

The system is now running on VPS, but only accessible locally (secure by design).

### Create SSH Tunnel

**On your laptop (NOT on VPS), open a new terminal:**

#### For Mac/Linux:

```bash
ssh -L 8501:localhost:8501 -L 8000:localhost:8000 root@203.0.113.45
```

#### For Windows (PuTTY):

1. Open PuTTY
2. Enter VPS IP in "Host Name"
3. Left sidebar: **Connection** → **SSH** → **Tunnels**
4. Add tunnel 1:
   - Source port: `8501`
   - Destination: `localhost:8501`
   - Click **Add**
5. Add tunnel 2:
   - Source port: `8000`
   - Destination: `localhost:8000`
   - Click **Add**
6. Go back to **Session**, click **Open**

### Open in Browser

With SSH tunnel active, open your browser:

- **Dashboard**: http://localhost:8501
- **API**: http://localhost:8000/status

**Keep the SSH terminal open!** If you close it, the tunnel breaks.

---

## PART 8: Verifying Everything Works

### Check Logs

On VPS:

```bash
cd ~/vivek_engine
tail -f logs/app.log
```

You should see:
```
INFO - Starting new strategy cycle
INFO - Fetching NIFTY data...
INFO - Current NIFTY price: ₹21,453.25
INFO - Signal: HOLD
```

Press **Ctrl+C** to exit log view.

### Check Data Files

```bash
cat data/state.json
cat data/signals.csv | head -20
```

### Test API

On VPS:
```bash
curl http://127.0.0.1:8000/status
```

Should return JSON with price, indicators, signal.

---

## PART 9: Auto-Start on Boot (Optional but Recommended)

To make services start automatically after VPS reboot:

### Create systemd service files

**1. Scheduler Service:**

```bash
sudo nano /etc/systemd/system/vivek-engine.service
```

Paste:
```ini
[Unit]
Description=NIFTY Trading Advisory Engine
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/vivek_engine
Environment="PATH=/root/vivek_engine/venv/bin"
ExecStart=/root/vivek_engine/venv/bin/python main_scheduler.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Save: **Ctrl+O**, Enter, **Ctrl+X**

**2. API Service:**

```bash
sudo nano /etc/systemd/system/vivek-api.service
```

Paste:
```ini
[Unit]
Description=NIFTY Trading Advisory API
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/vivek_engine
Environment="PATH=/root/vivek_engine/venv/bin"
ExecStart=/root/vivek_engine/venv/bin/uvicorn app.api:app --host 127.0.0.1 --port 8000
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Save and exit.

**3. Dashboard Service:**

```bash
sudo nano /etc/systemd/system/vivek-dashboard.service
```

Paste:
```ini
[Unit]
Description=NIFTY Trading Advisory Dashboard
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/vivek_engine
Environment="PATH=/root/vivek_engine/venv/bin"
ExecStart=/root/vivek_engine/venv/bin/streamlit run app/dashboard.py --server.address 127.0.0.1 --server.port 8501
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Save and exit.

### Enable Services

```bash
sudo systemctl daemon-reload
sudo systemctl enable vivek-engine.service
sudo systemctl enable vivek-api.service
sudo systemctl enable vivek-dashboard.service
sudo systemctl start vivek-engine.service
sudo systemctl start vivek-api.service
sudo systemctl start vivek-dashboard.service
```

### Check Status

```bash
sudo systemctl status vivek-engine.service
sudo systemctl status vivek-api.service
sudo systemctl status vivek-dashboard.service
```

Should show **"active (running)"** in green.

---

## PART 10: Daily Usage

### From Your Laptop

1. Open terminal
2. Create SSH tunnel:
   ```bash
   ssh -L 8501:localhost:8501 -L 8000:localhost:8000 root@your-vps-ip
   ```
3. Open browser:
   - Dashboard: http://localhost:8501
   - API: http://localhost:8000/status

### Check Signals

The dashboard shows:
- Current NIFTY price
- EMA9, EMA21, RSI
- Current signal (BUY, SELL, HOLD, etc.)
- Position state (NONE, LONG, SHORT)
- Recent signal history

### Understanding Signals

- **STRONG_BUY**: Consider going long
- **STRONG_SELL**: Consider going short
- **EXIT_LONG**: Exit long position
- **EXIT_SHORT**: Exit short position
- **HOLD**: No action needed
- **COOLDOWN**: Waiting period after exit

---

## 🔧 Troubleshooting

### Problem: "Connection refused" when accessing dashboard

**Solution:**
1. Check if services are running:
   ```bash
   sudo systemctl status vivek-engine.service
   sudo systemctl status vivek-dashboard.service
   ```
2. Check if SSH tunnel is active (on your laptop)
3. Restart services if needed:
   ```bash
   sudo systemctl restart vivek-dashboard.service
   ```

### Problem: No signals appearing

**Possible causes:**
- Market is closed (Indian market hours: 9:15 AM - 3:30 PM IST)
- First cycle hasn't completed (wait 5 minutes)
- Data fetch failed (check logs)

**Check logs:**
```bash
tail -f ~/vivek_engine/logs/app.log
```

### Problem: "Module not found" errors

**Solution:**
```bash
cd ~/vivek_engine
source venv/bin/activate
pip install -r requirements.txt
```

### Problem: Dashboard shows "No data available"

**Wait 5 minutes** for the first strategy cycle to complete.

If still no data:
```bash
# Check if data files exist
ls -la ~/vivek_engine/data/

# Check scheduler logs
tail -f ~/vivek_engine/logs/app.log
```

---

## 📊 Monitoring

### View Real-time Logs

```bash
# Main scheduler
tail -f ~/vivek_engine/logs/app.log

# API logs
sudo journalctl -u vivek-api.service -f

# Dashboard logs
sudo journalctl -u vivek-dashboard.service -f
```

### Check Service Status

```bash
sudo systemctl status vivek-engine.service
sudo systemctl status vivek-api.service
sudo systemctl status vivek-dashboard.service
```

### View Signal History

```bash
cat ~/vivek_engine/data/signals.csv | tail -20
```

---

## 🔒 Security Best Practices

1. **Never expose ports publicly** - Always use SSH tunnel
2. **Use SSH keys** instead of passwords (more secure)
3. **Regular backups**:
   ```bash
   tar -czf backup_$(date +%Y%m%d).tar.gz ~/vivek_engine/data/
   ```
4. **Keep system updated**:
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

---

## 💾 Backup and Restore

### Backup

```bash
cd ~
tar -czf vivek_backup_$(date +%Y%m%d).tar.gz vivek_engine/data/ vivek_engine/logs/

# Download to laptop using SCP
# On laptop:
scp root@your-vps-ip:~/vivek_backup_*.tar.gz ~/Downloads/
```

### Restore

```bash
cd ~
tar -xzf vivek_backup_20240115.tar.gz
```

---

## 📱 Next Steps

Once comfortable:

1. **Set up alerts**: Add Telegram/WhatsApp notifications
2. **Multiple strategies**: Create variants with different parameters
3. **Backtesting**: Test strategy on historical data
4. **Auto-execution** (Phase 2): Connect to broker API

---

## ❓ Common Questions

**Q: What hours does the engine run?**
A: 24/7, but NIFTY data is only available during market hours (9:15 AM - 3:30 PM IST, Mon-Fri)

**Q: Will it survive VPS restart?**
A: Yes, if you set up systemd services. State is persisted in `data/state.json`

**Q: How much does this cost to run?**
A: VPS: ~$5-10/month. No other costs.

**Q: Is this financial advice?**
A: NO. This is educational software only. Use at your own risk.

**Q: Can I change the strategy parameters?**
A: Yes, edit `app/strategy.py` - change RSI thresholds, EMA periods, etc.

**Q: How do I stop the engine?**
A: 
```bash
sudo systemctl stop vivek-engine.service
sudo systemctl stop vivek-api.service
sudo systemctl stop vivek-dashboard.service
```

---

## 🆘 Getting Help

1. Check logs: `tail -f ~/vivek_engine/logs/app.log`
2. Verify services: `sudo systemctl status vivek-engine.service`
3. Test API: `curl http://127.0.0.1:8000/status`
4. Review README.md for detailed documentation

---

**Remember**: This is an advisory system. It does NOT place trades. You make all trading decisions manually based on the signals.

**Good luck with your trading journey! 📈**
