#!/bin/bash
# Initialization script for NIFTY Trading Advisory Engine

echo "=========================================="
echo "NIFTY Trading Advisory Engine Setup"
echo "=========================================="
echo ""

# Create directories
echo "Creating directories..."
mkdir -p data logs

# Initialize state.json
echo "Initializing state.json..."
cat > data/state.json << 'EOF'
{
  "current_state": "NONE",
  "last_signal": null,
  "last_action_time_utc": null,
  "cooldown_end_time_utc": null
}
EOF

# Create empty signals.csv (headers will be added by app)
echo "Creating signals.csv..."
touch data/signals.csv

# Initialize latest_status.json
echo "Initializing latest_status.json..."
echo '{}' > data/latest_status.json

# Set permissions
echo "Setting permissions..."
chmod 644 data/*.json 2>/dev/null || true
chmod 644 data/*.csv 2>/dev/null || true
chmod 755 data logs

echo ""
echo "=========================================="
echo "Initialization Complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Activate virtual environment:"
echo "   source venv/bin/activate"
echo ""
echo "2. Run the main scheduler:"
echo "   python main_scheduler.py"
echo ""
echo "3. In separate terminals, run:"
echo "   - API: uvicorn app.api:app --host 127.0.0.1 --port 8000"
echo "   - Dashboard: streamlit run app/dashboard.py --server.address 127.0.0.1 --server.port 8501"
echo ""
echo "4. Access from laptop using SSH tunnel:"
echo "   ssh -L 8501:localhost:8501 -L 8000:localhost:8000 user@your-vps-ip"
echo ""
