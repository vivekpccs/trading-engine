"""
FastAPI REST API for trading advisory engine
"""
from fastapi import FastAPI, Query
from fastapi.responses import JSONResponse
import logging
from app.log_store import read_latest_status, read_signals_history

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="NIFTY Trading Advisory API",
    description="REST API for accessing trading signals and status",
    version="1.0.0"
)


@app.get("/")
async def root():
    """
    Root endpoint with API information
    """
    return {
        "name": "NIFTY Trading Advisory API",
        "version": "1.0.0",
        "status": "running",
        "endpoints": {
            "/status": "Get current trading status and latest signal",
            "/history": "Get historical signals (use ?limit=N parameter)"
        }
    }


@app.get("/status")
async def get_status():
    """
    Get current status and latest signal
    
    Returns:
        JSON with current price, indicators, signal, state, cooldown
    """
    try:
        status = read_latest_status()
        
        if not status:
            return JSONResponse(
                status_code=404,
                content={
                    "error": "No status available yet",
                    "message": "Engine may not have run yet. Check again in a few minutes."
                }
            )
        
        return status
        
    except Exception as e:
        logger.error(f"Error in /status endpoint: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"error": "Internal server error", "details": str(e)}
        )


@app.get("/history")
async def get_history(limit: int = Query(50, ge=1, le=500)):
    """
    Get historical signals
    
    Args:
        limit: Number of recent signals to return (1-500, default 50)
    
    Returns:
        JSON list of signal events
    """
    try:
        history = read_signals_history(limit=limit)
        
        return {
            "count": len(history),
            "limit": limit,
            "signals": history
        }
        
    except Exception as e:
        logger.error(f"Error in /history endpoint: {str(e)}")
        return JSONResponse(
            status_code=500,
            content={"error": "Internal server error", "details": str(e)}
        )


@app.get("/health")
async def health_check():
    """
    Health check endpoint
    """
    return {
        "status": "healthy",
        "service": "trading-advisory-api"
    }


# Note: When running, use:
# uvicorn app.api:app --host 127.0.0.1 --port 8000
# This binds to localhost only for security
