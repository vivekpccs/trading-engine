"""
Data source module for fetching NIFTY market data using yfinance
"""
import yfinance as yf
import pandas as pd
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


def fetch_nifty_data(symbol="^NSEI", interval="5m", days=2, max_retries=1):
    """
    Fetch NIFTY index data from Yahoo Finance
    
    Args:
        symbol: Yahoo Finance symbol for NIFTY
        interval: Data interval (5m for 5-minute candles)
        days: Number of days of historical data to fetch
        max_retries: Number of retry attempts on failure
    
    Returns:
        pandas.DataFrame with OHLCV data or None on failure
    """
    attempt = 0
    
    while attempt <= max_retries:
        try:
            logger.info(f"Fetching {symbol} data (attempt {attempt + 1}/{max_retries + 1})")
            
            # Calculate period
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=days)
            
            # Fetch data from yfinance
            ticker = yf.Ticker(symbol)
            df = ticker.history(
                start=start_date,
                end=end_date,
                interval=interval,
                auto_adjust=True
            )
            
            # Validate data
            if df is None or df.empty:
                logger.warning(f"No data returned for {symbol}")
                attempt += 1
                continue
            
            # Check for minimum required rows (need enough for indicators)
            if len(df) < 50:
                logger.warning(f"Insufficient data rows: {len(df)} < 50")
                attempt += 1
                continue
            
            # Check for required columns
            required_columns = ['Open', 'High', 'Low', 'Close', 'Volume']
            if not all(col in df.columns for col in required_columns):
                logger.warning(f"Missing required columns in data")
                attempt += 1
                continue
            
            # Use Close price as primary price
            df['Price'] = df['Close']
            
            logger.info(f"Successfully fetched {len(df)} rows of data for {symbol}")
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data (attempt {attempt + 1}): {str(e)}")
            attempt += 1
            
            if attempt > max_retries:
                logger.error(f"Failed to fetch data after {max_retries + 1} attempts")
                return None
    
    return None


def get_latest_price(df):
    """
    Extract the latest price from dataframe
    
    Args:
        df: pandas DataFrame with Price column
    
    Returns:
        float: Latest price or None
    """
    if df is None or df.empty:
        return None
    
    try:
        return float(df['Price'].iloc[-1])
    except Exception as e:
        logger.error(f"Error extracting latest price: {str(e)}")
        return None


def validate_data_quality(df):
    """
    Validate data quality and completeness
    
    Args:
        df: pandas DataFrame
    
    Returns:
        bool: True if data is valid, False otherwise
    """
    if df is None or df.empty:
        return False
    
    # Check for NaN values in critical columns
    critical_columns = ['Close', 'Price']
    for col in critical_columns:
        if col in df.columns and df[col].isna().any():
            logger.warning(f"NaN values found in {col} column")
            return False
    
    # Check for sufficient data points
    if len(df) < 30:
        logger.warning(f"Insufficient data points: {len(df)}")
        return False
    
    return True
