"""
State persistence module for storing engine state
"""
import json
import os
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

STATE_FILE_PATH = "data/state.json"


def get_default_state():
    """
    Get default initial state
    
    Returns:
        dict: Default state structure
    """
    return {
        "current_state": "NONE",
        "last_signal": None,
        "last_action_time_utc": None,
        "cooldown_end_time_utc": None
    }


def load_state():
    """
    Load state from JSON file
    
    Returns:
        dict: Current state or default state if file doesn't exist
    """
    try:
        if not os.path.exists(STATE_FILE_PATH):
            logger.warning(f"State file not found: {STATE_FILE_PATH}, creating default state")
            default_state = get_default_state()
            save_state(default_state)
            return default_state
        
        with open(STATE_FILE_PATH, 'r') as f:
            state = json.load(f)
            logger.info(f"State loaded: {state.get('current_state', 'UNKNOWN')}")
            return state
            
    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error in state file: {str(e)}")
        logger.warning("Resetting to default state")
        default_state = get_default_state()
        save_state(default_state)
        return default_state
        
    except Exception as e:
        logger.error(f"Error loading state: {str(e)}")
        return get_default_state()


def save_state(state):
    """
    Save state to JSON file atomically
    
    Args:
        state: dict containing state information
    """
    try:
        # Ensure data directory exists
        os.makedirs(os.path.dirname(STATE_FILE_PATH), exist_ok=True)
        
        # Write to temporary file first
        temp_file = STATE_FILE_PATH + '.tmp'
        with open(temp_file, 'w') as f:
            json.dump(state, f, indent=2)
        
        # Atomic rename
        os.replace(temp_file, STATE_FILE_PATH)
        
        logger.info(f"State saved: {state.get('current_state', 'UNKNOWN')}")
        
    except Exception as e:
        logger.error(f"Error saving state: {str(e)}")


def update_state(new_state_value, signal, cooldown_minutes=0):
    """
    Update state with new values
    
    Args:
        new_state_value: New state ('NONE', 'LONG', 'SHORT')
        signal: Signal that triggered the state change
        cooldown_minutes: Cooldown period in minutes (0 for no cooldown)
    
    Returns:
        dict: Updated state
    """
    try:
        current_time_utc = datetime.utcnow().isoformat()
        
        state = {
            "current_state": new_state_value,
            "last_signal": signal,
            "last_action_time_utc": current_time_utc,
            "cooldown_end_time_utc": None
        }
        
        # Set cooldown if specified
        if cooldown_minutes > 0:
            from datetime import timedelta
            cooldown_end = datetime.utcnow() + timedelta(minutes=cooldown_minutes)
            state["cooldown_end_time_utc"] = cooldown_end.isoformat()
            logger.info(f"Cooldown set for {cooldown_minutes} minutes until {cooldown_end.isoformat()}")
        
        save_state(state)
        return state
        
    except Exception as e:
        logger.error(f"Error updating state: {str(e)}")
        return load_state()


def is_in_cooldown(state):
    """
    Check if currently in cooldown period
    
    Args:
        state: Current state dict
    
    Returns:
        bool: True if in cooldown, False otherwise
    """
    try:
        cooldown_end_str = state.get('cooldown_end_time_utc')
        
        if cooldown_end_str is None:
            return False
        
        cooldown_end = datetime.fromisoformat(cooldown_end_str)
        now = datetime.utcnow()
        
        return now < cooldown_end
        
    except Exception as e:
        logger.error(f"Error checking cooldown: {str(e)}")
        return False


def get_cooldown_remaining_seconds(state):
    """
    Get remaining cooldown time in seconds
    
    Args:
        state: Current state dict
    
    Returns:
        int: Remaining seconds or 0 if not in cooldown
    """
    try:
        cooldown_end_str = state.get('cooldown_end_time_utc')
        
        if cooldown_end_str is None:
            return 0
        
        cooldown_end = datetime.fromisoformat(cooldown_end_str)
        now = datetime.utcnow()
        
        if now >= cooldown_end:
            return 0
        
        remaining = (cooldown_end - now).total_seconds()
        return int(remaining)
        
    except Exception as e:
        logger.error(f"Error calculating cooldown remaining: {str(e)}")
        return 0
