"""
Logging module for signals history and current status
"""
import csv
import json
import os
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

SIGNALS_CSV_PATH = "data/signals.csv"
LATEST_STATUS_JSON_PATH = "data/latest_status.json"

CSV_HEADERS = [
    'timestamp_utc',
    'symbol',
    'price',
    'ema9',
    'ema21',
    'rsi14',
    'signal',
    'state',
    'cooldown_remaining_sec'
]


def initialize_csv_if_needed():
    """
    Create CSV file with headers if it doesn't exist
    """
    try:
        os.makedirs(os.path.dirname(SIGNALS_CSV_PATH), exist_ok=True)
        
        if not os.path.exists(SIGNALS_CSV_PATH):
            with open(SIGNALS_CSV_PATH, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=CSV_HEADERS)
                writer.writeheader()
            logger.info(f"Created new CSV file: {SIGNALS_CSV_PATH}")
            
    except Exception as e:
        logger.error(f"Error initializing CSV: {str(e)}")


def append_to_csv(signal_data):
    """
    Append signal event to CSV file
    
    Args:
        signal_data: dict containing all signal information
    """
    try:
        initialize_csv_if_needed()
        
        row = {
            'timestamp_utc': signal_data.get('timestamp_utc', datetime.utcnow().isoformat()),
            'symbol': signal_data.get('symbol', '^NSEI'),
            'price': f"{signal_data.get('price', 0):.2f}",
            'ema9': f"{signal_data.get('ema9', 0):.2f}",
            'ema21': f"{signal_data.get('ema21', 0):.2f}",
            'rsi14': f"{signal_data.get('rsi14', 0):.2f}",
            'signal': signal_data.get('signal', 'HOLD'),
            'state': signal_data.get('state', 'NONE'),
            'cooldown_remaining_sec': signal_data.get('cooldown_remaining_sec', 0)
        }
        
        with open(SIGNALS_CSV_PATH, 'a', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=CSV_HEADERS)
            writer.writerow(row)
        
        logger.info(f"Logged to CSV: {row['signal']} at {row['price']}")
        
    except Exception as e:
        logger.error(f"Error appending to CSV: {str(e)}")


def write_latest_status(status_data):
    """
    Write current status to JSON file (overwrite)
    
    Args:
        status_data: dict containing current status
    """
    try:
        os.makedirs(os.path.dirname(LATEST_STATUS_JSON_PATH), exist_ok=True)
        
        # Add timestamp if not present
        if 'timestamp_utc' not in status_data:
            status_data['timestamp_utc'] = datetime.utcnow().isoformat()
        
        # Write atomically
        temp_file = LATEST_STATUS_JSON_PATH + '.tmp'
        with open(temp_file, 'w') as f:
            json.dump(status_data, f, indent=2)
        
        os.replace(temp_file, LATEST_STATUS_JSON_PATH)
        
        logger.debug("Updated latest_status.json")
        
    except Exception as e:
        logger.error(f"Error writing latest status: {str(e)}")


def read_latest_status():
    """
    Read current status from JSON file
    
    Returns:
        dict: Status data or empty dict if not found
    """
    try:
        if not os.path.exists(LATEST_STATUS_JSON_PATH):
            return {}
        
        with open(LATEST_STATUS_JSON_PATH, 'r') as f:
            return json.load(f)
            
    except Exception as e:
        logger.error(f"Error reading latest status: {str(e)}")
        return {}


def read_signals_history(limit=50):
    """
    Read last N rows from signals CSV
    
    Args:
        limit: Maximum number of rows to return
    
    Returns:
        list: List of signal dicts (most recent first)
    """
    try:
        if not os.path.exists(SIGNALS_CSV_PATH):
            return []
        
        with open(SIGNALS_CSV_PATH, 'r') as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        
        # Return last N rows, reversed (most recent first)
        return rows[-limit:][::-1] if rows else []
        
    except Exception as e:
        logger.error(f"Error reading signals history: {str(e)}")
        return []


def get_last_logged_price():
    """
    Get the last price that was logged to CSV
    Used for duplicate prevention logic
    
    Returns:
        float: Last logged price or None
    """
    try:
        history = read_signals_history(limit=1)
        if history:
            return float(history[0].get('price', 0))
        return None
    except Exception as e:
        logger.error(f"Error getting last logged price: {str(e)}")
        return None
