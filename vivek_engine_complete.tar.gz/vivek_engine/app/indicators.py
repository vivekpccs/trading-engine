"""
Technical indicators calculation module
"""
import pandas as pd
import numpy as np
import logging

logger = logging.getLogger(__name__)


def calculate_ema(df, period):
    """
    Calculate Exponential Moving Average
    
    Args:
        df: pandas DataFrame with 'Price' or 'Close' column
        period: EMA period (e.g., 9, 21)
    
    Returns:
        pandas.Series with EMA values
    """
    if df is None or df.empty:
        return None
    
    try:
        price_col = 'Price' if 'Price' in df.columns else 'Close'
        ema = df[price_col].ewm(span=period, adjust=False).mean()
        return ema
    except Exception as e:
        logger.error(f"Error calculating EMA({period}): {str(e)}")
        return None


def calculate_rsi(df, period=14):
    """
    Calculate Relative Strength Index (RSI)
    
    Args:
        df: pandas DataFrame with 'Price' or 'Close' column
        period: RSI period (default 14)
    
    Returns:
        pandas.Series with RSI values
    """
    if df is None or df.empty:
        return None
    
    try:
        price_col = 'Price' if 'Price' in df.columns else 'Close'
        delta = df[price_col].diff()
        
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        
        avg_gain = gain.ewm(span=period, adjust=False).mean()
        avg_loss = loss.ewm(span=period, adjust=False).mean()
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    except Exception as e:
        logger.error(f"Error calculating RSI({period}): {str(e)}")
        return None


def calculate_all_indicators(df):
    """
    Calculate all required indicators: EMA9, EMA21, RSI14
    
    Args:
        df: pandas DataFrame with price data
    
    Returns:
        dict with indicator values or None if calculation fails
    """
    if df is None or df.empty:
        logger.error("Cannot calculate indicators: empty dataframe")
        return None
    
    try:
        # Calculate indicators
        ema9 = calculate_ema(df, 9)
        ema21 = calculate_ema(df, 21)
        rsi14 = calculate_rsi(df, 14)
        
        # Check for None returns
        if ema9 is None or ema21 is None or rsi14 is None:
            logger.error("One or more indicators returned None")
            return None
        
        # Get latest values
        latest_ema9 = float(ema9.iloc[-1])
        latest_ema21 = float(ema21.iloc[-1])
        latest_rsi14 = float(rsi14.iloc[-1])
        
        # Get previous values for crossover detection
        prev_ema9 = float(ema9.iloc[-2]) if len(ema9) >= 2 else latest_ema9
        prev_ema21 = float(ema21.iloc[-2]) if len(ema21) >= 2 else latest_ema21
        
        # Check for NaN values
        if np.isnan(latest_ema9) or np.isnan(latest_ema21) or np.isnan(latest_rsi14):
            logger.warning("NaN values detected in indicators")
            return None
        
        indicators = {
            'ema9': latest_ema9,
            'ema21': latest_ema21,
            'rsi14': latest_rsi14,
            'prev_ema9': prev_ema9,
            'prev_ema21': prev_ema21
        }
        
        logger.info(f"Indicators calculated: EMA9={latest_ema9:.2f}, EMA21={latest_ema21:.2f}, RSI={latest_rsi14:.2f}")
        return indicators
        
    except Exception as e:
        logger.error(f"Error calculating indicators: {str(e)}")
        return None


def detect_crossover(current_fast, current_slow, prev_fast, prev_slow):
    """
    Detect crossover between two moving averages
    
    Args:
        current_fast: Current value of faster MA (e.g., EMA9)
        current_slow: Current value of slower MA (e.g., EMA21)
        prev_fast: Previous value of faster MA
        prev_slow: Previous value of slower MA
    
    Returns:
        str: 'bullish' for upward cross, 'bearish' for downward cross, 'none' otherwise
    """
    # Bullish crossover: fast crosses above slow
    if prev_fast <= prev_slow and current_fast > current_slow:
        return 'bullish'
    
    # Bearish crossover: fast crosses below slow
    if prev_fast >= prev_slow and current_fast < current_slow:
        return 'bearish'
    
    return 'none'
