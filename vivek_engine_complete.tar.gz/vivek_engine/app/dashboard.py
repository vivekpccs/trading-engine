"""
Streamlit dashboard for monitoring trading advisory engine
"""
import streamlit as st
import pandas as pd
from datetime import datetime
import time
from app.log_store import read_latest_status, read_signals_history
from app.state_store import get_cooldown_remaining_seconds, load_state

# Page configuration
st.set_page_config(
    page_title="NIFTY Trading Advisory",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .big-metric {
        font-size: 2.5rem;
        font-weight: bold;
    }
    .signal-box {
        padding: 20px;
        border-radius: 10px;
        text-align: center;
        font-size: 1.5rem;
        font-weight: bold;
        margin: 10px 0;
    }
    .signal-buy {
        background-color: #d4edda;
        color: #155724;
        border: 2px solid #28a745;
    }
    .signal-sell {
        background-color: #f8d7da;
        color: #721c24;
        border: 2px solid #dc3545;
    }
    .signal-exit {
        background-color: #fff3cd;
        color: #856404;
        border: 2px solid #ffc107;
    }
    .signal-hold {
        background-color: #d1ecf1;
        color: #0c5460;
        border: 2px solid #17a2b8;
    }
    .signal-cooldown {
        background-color: #e2e3e5;
        color: #383d41;
        border: 2px solid #6c757d;
    }
    .state-box {
        padding: 10px;
        border-radius: 5px;
        text-align: center;
        font-weight: bold;
    }
    .state-long {
        background-color: #d4edda;
        color: #155724;
    }
    .state-short {
        background-color: #f8d7da;
        color: #721c24;
    }
    .state-none {
        background-color: #e2e3e5;
        color: #383d41;
    }
</style>
""", unsafe_allow_html=True)


def get_signal_css_class(signal):
    """Get CSS class for signal display"""
    signal_classes = {
        'STRONG_BUY': 'signal-buy',
        'STRONG_SELL': 'signal-sell',
        'EXIT_LONG': 'signal-exit',
        'EXIT_SHORT': 'signal-exit',
        'HOLD': 'signal-hold',
        'COOLDOWN': 'signal-cooldown'
    }
    return signal_classes.get(signal, 'signal-hold')


def get_state_css_class(state):
    """Get CSS class for state display"""
    state_classes = {
        'LONG': 'state-long',
        'SHORT': 'state-short',
        'NONE': 'state-none'
    }
    return state_classes.get(state, 'state-none')


def format_cooldown(seconds):
    """Format cooldown seconds as MM:SS"""
    if seconds <= 0:
        return "None"
    minutes = seconds // 60
    secs = seconds % 60
    return f"{minutes:02d}:{secs:02d}"


# Main dashboard
st.title("📈 NIFTY Trading Advisory Dashboard")
st.markdown("---")

# Auto-refresh mechanism
auto_refresh = st.sidebar.checkbox("Auto-refresh (30s)", value=True)
if auto_refresh:
    time.sleep(0.1)  # Small delay to prevent too rapid refresh
    st.rerun()

# Refresh button
if st.sidebar.button("🔄 Refresh Now"):
    st.rerun()

# Read current status
status = read_latest_status()

if not status:
    st.error("⚠️ No data available yet. Engine may not have run. Please wait...")
    st.info("The advisory engine runs every 5 minutes. Check back soon.")
    st.stop()

# Extract status data
price = status.get('price', 0)
ema9 = status.get('ema9', 0)
ema21 = status.get('ema21', 0)
rsi14 = status.get('rsi14', 0)
signal = status.get('signal', 'UNKNOWN')
state = status.get('state', 'NONE')
cooldown_remaining = status.get('cooldown_remaining_sec', 0)
timestamp = status.get('timestamp_utc', 'Unknown')
reason = status.get('reason', 'No reason provided')

# Top metrics row
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("NIFTY Price", f"₹{price:,.2f}")

with col2:
    ema_trend = "📈" if ema9 > ema21 else "📉"
    st.metric("EMA Trend", ema_trend, f"EMA9: {ema9:.2f}")

with col3:
    rsi_color = "🟢" if rsi14 > 50 else "🔴"
    st.metric("RSI (14)", f"{rsi_color} {rsi14:.2f}")

with col4:
    st.metric("Last Update", timestamp.split('T')[1][:8] if 'T' in timestamp else timestamp)

st.markdown("---")

# Current signal and state
col_sig, col_state = st.columns(2)

with col_sig:
    st.subheader("Current Signal")
    signal_class = get_signal_css_class(signal)
    st.markdown(f'<div class="signal-box {signal_class}">{signal}</div>', unsafe_allow_html=True)
    st.caption(f"**Reason:** {reason}")

with col_state:
    st.subheader("Position State")
    state_class = get_state_css_class(state)
    st.markdown(f'<div class="state-box {state_class}">{state}</div>', unsafe_allow_html=True)
    
    if cooldown_remaining > 0:
        st.warning(f"⏱️ Cooldown: {format_cooldown(cooldown_remaining)} remaining")
    else:
        st.success("✅ Ready for new signals")

st.markdown("---")

# Detailed indicators
st.subheader("📊 Technical Indicators")
ind_col1, ind_col2, ind_col3 = st.columns(3)

with ind_col1:
    st.metric("EMA (9)", f"{ema9:.2f}")

with ind_col2:
    st.metric("EMA (21)", f"{ema21:.2f}")

with ind_col3:
    st.metric("RSI (14)", f"{rsi14:.2f}")

# EMA position
if ema9 > ema21:
    st.info("🔵 EMA9 is **above** EMA21 (Bullish alignment)")
else:
    st.info("🔴 EMA9 is **below** EMA21 (Bearish alignment)")

st.markdown("---")

# Signal history
st.subheader("📜 Recent Signal History")

history = read_signals_history(limit=50)

if history:
    # Convert to DataFrame
    df = pd.DataFrame(history)
    
    # Format numeric columns
    numeric_cols = ['price', 'ema9', 'ema21', 'rsi14']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').round(2)
    
    # Format timestamp
    if 'timestamp_utc' in df.columns:
        df['timestamp_utc'] = pd.to_datetime(df['timestamp_utc']).dt.strftime('%Y-%m-%d %H:%M:%S')
    
    # Rename columns for display
    display_columns = {
        'timestamp_utc': 'Timestamp',
        'symbol': 'Symbol',
        'price': 'Price',
        'ema9': 'EMA9',
        'ema21': 'EMA21',
        'rsi14': 'RSI',
        'signal': 'Signal',
        'state': 'State',
        'cooldown_remaining_sec': 'Cooldown (s)'
    }
    
    df_display = df.rename(columns=display_columns)
    
    # Display table
    st.dataframe(
        df_display,
        use_container_width=True,
        height=400
    )
    
    # Summary stats
    st.caption(f"Showing last {len(history)} signals")
    
else:
    st.info("No historical data available yet.")

# Footer
st.markdown("---")
st.caption(f"Advisory Engine v1.0 | Data updates every 5 minutes | Current time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")

# Auto-refresh countdown
if auto_refresh:
    placeholder = st.empty()
    for i in range(30, 0, -1):
        placeholder.caption(f"⏱️ Auto-refreshing in {i} seconds...")
        time.sleep(1)
    placeholder.empty()
    st.rerun()
