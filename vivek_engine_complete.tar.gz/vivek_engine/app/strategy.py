"""
Trading strategy module with state machine logic
"""
import logging
from app.indicators import detect_crossover
from app.state_store import load_state, update_state, is_in_cooldown

logger = logging.getLogger(__name__)

# Signal constants
SIGNAL_STRONG_BUY = "STRONG_BUY"
SIGNAL_STRONG_SELL = "STRONG_SELL"
SIGNAL_EXIT_LONG = "EXIT_LONG"
SIGNAL_EXIT_SHORT = "EXIT_SHORT"
SIGNAL_HOLD = "HOLD"
SIGNAL_COOLDOWN = "COOLDOWN"

# State constants
STATE_NONE = "NONE"
STATE_LONG = "LONG"
STATE_SHORT = "SHORT"

# Strategy parameters
RSI_BUY_THRESHOLD = 55
RSI_SELL_THRESHOLD = 45
COOLDOWN_MINUTES = 15


def generate_signal(indicators, price):
    """
    Generate trading signal based on indicators and current state
    
    Args:
        indicators: dict with ema9, ema21, rsi14, prev_ema9, prev_ema21
        price: current market price
    
    Returns:
        dict: {
            'signal': signal name,
            'state': new state,
            'reason': explanation,
            'action_taken': bool
        }
    """
    if indicators is None:
        logger.warning("Cannot generate signal: indicators are None")
        return {
            'signal': SIGNAL_HOLD,
            'state': STATE_NONE,
            'reason': 'Insufficient data',
            'action_taken': False
        }
    
    try:
        # Load current state
        state = load_state()
        current_state = state.get('current_state', STATE_NONE)
        
        # Check cooldown
        if is_in_cooldown(state):
            logger.info("In cooldown period - blocking new entries")
            return {
                'signal': SIGNAL_COOLDOWN,
                'state': current_state,
                'reason': 'Cooldown active after exit',
                'action_taken': False
            }
        
        # Extract indicators
        ema9 = indicators['ema9']
        ema21 = indicators['ema21']
        rsi = indicators['rsi14']
        prev_ema9 = indicators['prev_ema9']
        prev_ema21 = indicators['prev_ema21']
        
        # Detect crossover
        crossover = detect_crossover(ema9, ema21, prev_ema9, prev_ema21)
        
        logger.info(f"Strategy check: State={current_state}, Crossover={crossover}, RSI={rsi:.2f}")
        
        # Strategy logic
        
        # EXIT LONG: If currently LONG and bearish crossover
        if current_state == STATE_LONG and crossover == 'bearish':
            logger.info("EXIT_LONG triggered: EMA9 crossed below EMA21")
            update_state(STATE_NONE, SIGNAL_EXIT_LONG, cooldown_minutes=COOLDOWN_MINUTES)
            return {
                'signal': SIGNAL_EXIT_LONG,
                'state': STATE_NONE,
                'reason': f'EMA9 ({ema9:.2f}) crossed below EMA21 ({ema21:.2f})',
                'action_taken': True
            }
        
        # EXIT SHORT: If currently SHORT and bullish crossover
        if current_state == STATE_SHORT and crossover == 'bullish':
            logger.info("EXIT_SHORT triggered: EMA9 crossed above EMA21")
            update_state(STATE_NONE, SIGNAL_EXIT_SHORT, cooldown_minutes=COOLDOWN_MINUTES)
            return {
                'signal': SIGNAL_EXIT_SHORT,
                'state': STATE_NONE,
                'reason': f'EMA9 ({ema9:.2f}) crossed above EMA21 ({ema21:.2f})',
                'action_taken': True
            }
        
        # STRONG BUY: Bullish crossover + RSI > 55 + state NONE
        if current_state == STATE_NONE and crossover == 'bullish' and rsi > RSI_BUY_THRESHOLD:
            logger.info(f"STRONG_BUY triggered: Bullish crossover + RSI {rsi:.2f} > {RSI_BUY_THRESHOLD}")
            update_state(STATE_LONG, SIGNAL_STRONG_BUY, cooldown_minutes=0)
            return {
                'signal': SIGNAL_STRONG_BUY,
                'state': STATE_LONG,
                'reason': f'EMA9 crossed above EMA21, RSI={rsi:.2f} > {RSI_BUY_THRESHOLD}',
                'action_taken': True
            }
        
        # STRONG SELL: Bearish crossover + RSI < 45 + state NONE
        if current_state == STATE_NONE and crossover == 'bearish' and rsi < RSI_SELL_THRESHOLD:
            logger.info(f"STRONG_SELL triggered: Bearish crossover + RSI {rsi:.2f} < {RSI_SELL_THRESHOLD}")
            update_state(STATE_SHORT, SIGNAL_STRONG_SELL, cooldown_minutes=0)
            return {
                'signal': SIGNAL_STRONG_SELL,
                'state': STATE_SHORT,
                'reason': f'EMA9 crossed below EMA21, RSI={rsi:.2f} < {RSI_SELL_THRESHOLD}',
                'action_taken': True
            }
        
        # HOLD: No conditions met
        reason = _get_hold_reason(current_state, crossover, rsi, ema9, ema21)
        return {
            'signal': SIGNAL_HOLD,
            'state': current_state,
            'reason': reason,
            'action_taken': False
        }
        
    except Exception as e:
        logger.error(f"Error generating signal: {str(e)}")
        return {
            'signal': SIGNAL_HOLD,
            'state': STATE_NONE,
            'reason': f'Error: {str(e)}',
            'action_taken': False
        }


def _get_hold_reason(current_state, crossover, rsi, ema9, ema21):
    """
    Generate human-readable reason for HOLD signal
    
    Args:
        current_state: Current position state
        crossover: Crossover type
        rsi: RSI value
        ema9: EMA9 value
        ema21: EMA21 value
    
    Returns:
        str: Explanation for HOLD
    """
    if current_state == STATE_LONG:
        return f'Holding LONG position. EMA9={ema9:.2f}, EMA21={ema21:.2f}'
    
    if current_state == STATE_SHORT:
        return f'Holding SHORT position. EMA9={ema9:.2f}, EMA21={ema21:.2f}'
    
    if crossover == 'bullish' and rsi <= RSI_BUY_THRESHOLD:
        return f'Bullish crossover but RSI {rsi:.2f} <= {RSI_BUY_THRESHOLD} (weak momentum)'
    
    if crossover == 'bearish' and rsi >= RSI_SELL_THRESHOLD:
        return f'Bearish crossover but RSI {rsi:.2f} >= {RSI_SELL_THRESHOLD} (weak momentum)'
    
    return f'No crossover detected. EMA9={ema9:.2f}, EMA21={ema21:.2f}, RSI={rsi:.2f}'


def should_log_to_history(new_signal_data, last_logged_price):
    """
    Determine if this signal should be logged to CSV
    Prevents duplicate HOLD spam
    
    Args:
        new_signal_data: dict with signal, state, price
        last_logged_price: last price logged to CSV (or None)
    
    Returns:
        bool: True if should log, False otherwise
    """
    signal = new_signal_data.get('signal')
    price = new_signal_data.get('price', 0)
    
    # Always log actionable signals
    actionable_signals = [SIGNAL_STRONG_BUY, SIGNAL_STRONG_SELL, 
                          SIGNAL_EXIT_LONG, SIGNAL_EXIT_SHORT]
    
    if signal in actionable_signals:
        return True
    
    # Log COOLDOWN at start
    if signal == SIGNAL_COOLDOWN:
        # Only log if this is first cooldown detection
        # (state store handles this via action_taken flag)
        return new_signal_data.get('action_taken', False)
    
    # For HOLD: only log if price moved significantly (>0.5%)
    if signal == SIGNAL_HOLD:
        if last_logged_price is None:
            return True  # First ever log
        
        price_change_pct = abs((price - last_logged_price) / last_logged_price * 100)
        if price_change_pct > 0.5:
            return True
        
        return False
    
    return True
